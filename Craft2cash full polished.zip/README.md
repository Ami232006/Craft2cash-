# Craft2Cash - Prototype

This is a Vite + React + Tailwind prototype for Craft2Cash.

## Features (implemented)
- Artist Hub: view artists and their works (polaroid style)
- Sales Hub: view artworks available for sale
- Mock Auth: login as `artist` or `customer` (localStorage)
- Artists can upload artworks (images are saved as base64 in localStorage for demo)
- Dark mode (toggle in nav)
- Local persistence via localStorage

## Run locally
1. `npm install`
2. `npm run dev`
3. Open `http://localhost:5173`

Notes:
- This is a demo prototype. For production, integrate a backend (for auth, file storage, payments).
