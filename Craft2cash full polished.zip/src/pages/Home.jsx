import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <div className="text-center py-20">
      <h1 className="text-4xl font-bold mb-4">Craft2Cash</h1>
      <p className="mb-6 text-lg text-slate-500 dark:text-slate-300">Discover artists and buy handmade art directly from creators.</p>
      <div className="flex justify-center gap-4">
        <Link to="/artist-hub" className="px-6 py-3 bg-white dark:bg-slate-700 rounded shadow">Artist Hub</Link>
        <Link to="/sales-hub" className="px-6 py-3 bg-white dark:bg-slate-700 rounded shadow">Sales Hub</Link>
      </div>
    </div>
  );
}
