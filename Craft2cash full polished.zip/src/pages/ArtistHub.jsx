import React, { useEffect, useState } from 'react';
import { LS } from '../utils/storage';
import ArtistCard from '../components/ArtistCard';
import UploadForm from '../components/UploadForm';
import { useAuth } from '../components/AuthProvider';

export default function ArtistHub(){
  const [artists, setArtists] = useState(LS.get('artists', []));
  const [artworks, setArtworks] = useState(LS.get('artworks', []));
  const { user } = useAuth();

  useEffect(()=>{ LS.set('artists', artists); }, [artists]);
  useEffect(()=>{ LS.set('artworks', artworks); }, [artworks]);

  function handleUpload(newArt){
    setArtworks(prev => [newArt, ...prev]);
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Artist Hub</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {artists.map(a=> <ArtistCard key={a.id} artist={a} artworks={artworks.filter(w=>w.artistId===a.id)} />)}
      </div>

      <div className="mt-8">
        <h3 className="text-xl mb-2">Upload your work (Artists only)</h3>
        {user && user.role === 'artist' ? (
          <UploadForm artists={artists} onUpload={handleUpload} />
        ) : (
          <div className="text-sm text-slate-500">Log in as an <strong>artist</strong> to upload artworks.</div>
        )}
      </div>
    </div>
  );
}
