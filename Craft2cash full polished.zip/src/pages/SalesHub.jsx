import React, { useEffect, useState } from 'react';
import { LS } from '../utils/storage';
import { useAuth } from '../components/AuthProvider';

export default function SalesHub(){
  const [artworks, setArtworks] = useState(LS.get('artworks', []).filter(a=>a.forSale));
  const { user, login } = useAuth();

  useEffect(()=>{ setArtworks(LS.get('artworks', []).filter(a=>a.forSale)); }, []);

  function contactArtist(art){
    const artists = LS.get('artists', []);
    const artist = artists.find(a=>a.id === art.artistId);
    if(artist){
      alert(`Contact ${artist.name} at ${artist.contact || 'no contact provided'}`);
    } else alert('Artist not found');
  }

  function buyNow(art){
    if(!user){
      if(window.confirm('You must log in to purchase. Log in now?')) {
        // simple prompt for demo (in real app show modal)
        const username = prompt('Enter username for demo login');
        if(username) login(username, 'customer');
        else return;
      } else return;
    }
    alert(`Purchase flow (demo): ${art.title} by ${art.artistId} — $${art.price}.\nIn production integrate Stripe/PayPal.`);
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Sales Hub</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {artworks.map(w=> (
          <div key={w.id} className="polaroid">
            <div className="h-48 flex items-center justify-center mb-2 overflow-hidden">
              {w.image ? <img src={w.image} alt={w.title} className="w-full object-cover h-full" /> : <div className="text-sm">No Image</div>}
            </div>
            <div className="font-semibold">{w.title}</div>
            <div className="text-sm text-slate-500">${w.price}</div>
            <div className="mt-2 flex gap-2">
              <button onClick={()=>contactArtist(w)} className="px-3 py-1 bg-slate-800 text-white rounded">Contact Artist</button>
              <button onClick={()=>buyNow(w)} className="px-3 py-1 border rounded">Buy Now</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
