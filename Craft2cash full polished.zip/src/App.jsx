import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { seedIfEmpty } from './data/seed';
import { LS } from './utils/storage';
import Nav from './components/Nav';
import Home from './pages/Home';
import ArtistHub from './pages/ArtistHub';
import SalesHub from './pages/SalesHub';
import AuthProvider from './components/AuthProvider';

export default function App(){
  seedIfEmpty();
  const [dark, setDark] = useState(false);
  useEffect(()=>{ document.documentElement.classList.toggle('dark', dark); }, [dark]);

  return (
    <AuthProvider>
      <div className="min-h-screen transition-colors">
        <Nav dark={dark} setDark={setDark} />
        <main className="max-w-6xl mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/artist-hub" element={<ArtistHub />} />
            <Route path="/sales-hub" element={<SalesHub />} />
          </Routes>
        </main>
      </div>
    </AuthProvider>
  );
}
