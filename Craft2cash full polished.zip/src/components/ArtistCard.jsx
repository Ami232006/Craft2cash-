import React from 'react';
import ArtworkPolaroid from './ArtworkPolaroid';

export default function ArtistCard({ artist, artworks=[] }){
  return (
    <div className="p-4">
      <div className="polaroid">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-sm">{artist.name.split(' ').map(n=>n[0]).slice(0,2).join('')}</div>
          <div>
            <div className="font-semibold">{artist.name}</div>
            <div className="text-sm text-slate-500">{artist.bio}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {artworks.slice(0,4).map(w=> <ArtworkPolaroid key={w.id} artwork={w} />)}
        </div>
      </div>
    </div>
  );
}
