import React, { createContext, useContext, useState, useEffect } from 'react';
import { LS, uid } from '../utils/storage';

const AuthContext = createContext();
export function useAuth(){ return useContext(AuthContext); }

export default function AuthProvider({ children }){
  const [user, setUser] = useState(LS.get('currentUser', null));
  useEffect(()=>{ LS.set('currentUser', user); }, [user]);

  const login = (username, role) => {
    // role: 'artist' | 'customer'
    // simple mock: create user with role
    const u = { id: uid(), username, role };
    setUser(u);
    return u;
  };
  const logout = () => setUser(null);

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
