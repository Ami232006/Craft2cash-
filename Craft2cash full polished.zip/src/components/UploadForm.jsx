import React, { useState } from 'react';
import { uid } from '../utils/storage';

function toBase64(file){
  return new Promise((res, rej)=>{
    const reader = new FileReader();
    reader.onload = () => res(reader.result);
    reader.onerror = rej;
    reader.readAsDataURL(file);
  });
}

export default function UploadForm({ artists, onUpload }){
  const [form, setForm] = useState({ title:'', artistId: artists[0]?.id || '', price: 0, description:'', forSale: true });
  const [filePreview, setFilePreview] = useState(null);

  async function onFile(e){
    const f = e.target.files[0];
    if(!f) return;
    const b = await toBase64(f);
    setFilePreview(b);
  }

  async function submit(e){
    e.preventDefault();
    const newArt = { id: uid(), ...form, image: filePreview };
    onUpload(newArt);
    setForm({ title:'', artistId: artists[0]?.id || '', price: 0, description:'', forSale: true });
    setFilePreview(null);
  }

  return (
    <form onSubmit={submit} className="max-w-xl">
      <div className="grid grid-cols-1 gap-2">
        <input required value={form.title} onChange={e=>setForm({...form, title:e.target.value})} placeholder="Title" className="p-2 rounded" />
        <select value={form.artistId} onChange={e=>setForm({...form, artistId:e.target.value})} className="p-2 rounded">
          {artists.map(a=> <option key={a.id} value={a.id}>{a.name}</option>)}
        </select>
        <input type="number" value={form.price} onChange={e=>setForm({...form, price: Number(e.target.value)})} className="p-2 rounded" />
        <textarea value={form.description} onChange={e=>setForm({...form, description: e.target.value})} className="p-2 rounded" placeholder="Description" />
        <input type="file" accept="image/*" onChange={onFile} />
        {filePreview && <img src={filePreview} alt="preview" className="h-28 object-cover rounded" />}
        <button className="px-4 py-2 bg-slate-800 text-white rounded">Upload</button>
      </div>
    </form>
  );
}
