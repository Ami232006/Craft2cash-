import React from 'react';

export default function ArtworkPolaroid({ artwork }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-md p-2 text-center">
      <div className="w-full h-36 bg-slate-100 dark:bg-slate-700 rounded-md mb-2 flex items-center justify-center overflow-hidden">
        {artwork.image ? <img src={artwork.image} alt={artwork.title} className="object-cover w-full h-full" /> : <div className="text-xs">{artwork.title}</div>}
      </div>
      <div className="text-sm font-medium">{artwork.title}</div>
      <div className="text-xs text-slate-500">${artwork.price}</div>
    </div>
  );
}
