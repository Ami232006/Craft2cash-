import React, { useState } from 'react';
import { useAuth } from './AuthProvider';

export default function AuthModal({ onClose }){
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [role, setRole] = useState('customer');

  function submit(e){
    e.preventDefault();
    if(!username) return alert('Enter a username');
    login(username, role);
    onClose();
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/40">
      <form onSubmit={submit} className="bg-white dark:bg-slate-800 p-6 rounded shadow max-w-sm w-full">
        <h3 className="text-lg font-semibold mb-3">Login / Signup (Mock)</h3>
        <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" className="w-full p-2 rounded mb-2" />
        <select value={role} onChange={e=>setRole(e.target.value)} className="w-full p-2 rounded mb-3">
          <option value="customer">Customer</option>
          <option value="artist">Artist</option>
        </select>
        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose} className="px-3 py-1 border rounded">Cancel</button>
          <button className="px-3 py-1 bg-slate-800 text-white rounded">Login</button>
        </div>
      </form>
    </div>
  );
}
