import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import AuthModal from './AuthModal';

export default function Nav({ dark, setDark }){
  const loc = useLocation();
  const { user, logout } = useAuth();
  const [showAuth, setShowAuth] = React.useState(false);

  return (
    <header className="bg-white dark:bg-slate-800 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="font-semibold text-lg">Craft2Cash</Link>
        <nav className="flex items-center gap-4">
          <Link to="/artist-hub" className={`px-3 py-1 rounded ${loc.pathname==='/artist-hub'? 'bg-slate-200 dark:bg-slate-700':'hover:bg-slate-50 dark:hover:bg-slate-700'}`}>Artist Hub</Link>
          <Link to="/sales-hub" className={`px-3 py-1 rounded ${loc.pathname==='/sales-hub'? 'bg-slate-200 dark:bg-slate-700':'hover:bg-slate-50 dark:hover:bg-slate-700'}`}>Sales Hub</Link>
          <button onClick={()=>setDark(d=>!d)} className="px-3 py-1 rounded">{dark? 'Light' : 'Dark'}</button>
          {user ? (
            <div className="flex items-center gap-2">
              <div className="text-sm">{user.username} ({user.role})</div>
              <button onClick={logout} className="px-3 py-1 border rounded">Logout</button>
            </div>
          ) : (
            <button onClick={()=>setShowAuth(true)} className="px-3 py-1 bg-slate-800 text-white rounded">Login</button>
          )}
        </nav>
      </div>
      {showAuth && <AuthModal onClose={()=>setShowAuth(false)} />}
    </header>
  );
}
