import { LS } from '../utils/storage';

export function seedIfEmpty(){
  if(!LS.get('artists')){
    const artists = [
      { id: 'a1', name: 'Anika Rao', avatar: '', bio: 'Painter & mixed media', social: { instagram: '' }, contact: 'anika@example.com' },
      { id: 'a2', name: 'Rohan Verma', avatar: '', bio: 'Crochet & crafts', social: { instagram: '' }, contact: 'rohan@example.com' }
    ];
    const artworks = [
      { id: 'w1', artistId: 'a1', title: 'Blue Horizon', description: 'Acrylic on canvas', category: 'Painting', price: 120, image: '', forSale: true },
      { id: 'w2', artistId: 'a1', title: 'Dusk Study', description: 'Charcoal sketch', category: 'Drawing', price: 45, image: '', forSale: false },
      { id: 'w3', artistId: 'a2', title: 'Sun Scarf', description: 'Handmade crochet scarf', category: 'Crochet', price: 35, image: '', forSale: true }
    ];
    LS.set('artists', artists);
    LS.set('artworks', artworks);
  }
}
