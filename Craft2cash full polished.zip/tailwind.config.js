module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: 'class',
  theme: {
    extend: {
      boxShadow: {
        'polaroid': '0 10px 30px rgba(0,0,0,0.35)'
      }
    }
  },
  plugins: [],
}
